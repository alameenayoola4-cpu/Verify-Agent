# VerifyAgent - 5-Minute Demo Video Script

## 0:00 - 0:30 | The Hook & The Problem
**Visual:** Show the README title or your face.
**Script:** 
"Hi, I'm [Your Name] and this is VerifyAgent. 
Today, developers use LLMs to write code constantly, but there's a major bottleneck: the *Verification Gap*. An LLM can confidently generate code that looks right, but contains subtle logical errors. Right now, companies use static 'AI reviewers' to check the code, which is basically just AI-washing. A static review often hallucinates or misses real bugs. 
Real engineering requires execution. So, I built an agent that doesn't just read code—it attacks it in a sandbox."

## 0:30 - 2:00 | The Solution & Architecture
**Visual:** Show the code structure (`src/agent/orchestrator.py`) or a diagram if you have one.
**Script:**
"VerifyAgent uses a 6-phase execution loop. 
1. It reads the code and spec. 
2. It generates 12 aggressive adversarial test cases.
3. It securely executes those tests in a Python subprocess sandbox.
4. It analyzes the actual tracebacks and stdout to diagnose root causes.
5. It applies a fix.
6. It loops until the tests pass."

## 2:00 - 3:30 | The Demo (Baseline vs VerifyAgent)
**Visual:** Open your terminal and show the `results/COMPARISON.md` or run the scripts live.
**Script:**
"Let's look at it in action. I created a benchmark of 10 common AI-generated coding mistakes. Let's take Case 1: an Array Utility with a subtle off-by-one error in a sliding window.

*(Show the terminal or COMPARISON.md)*
When we use a standard static LLM reviewer, it spots a couple of potential issues, but it has no idea if the code actually works. It's just guessing. 

But when we run VerifyAgent... it generates tests, and actually catches the sliding window failing on edge cases. It takes those exact tracebacks, feeds them into the diagnosis module, patches the code, and re-runs it. As you can see here, it brought the test suite to a perfect 12 out of 12 pass rate, proving the fix works."

## 3:30 - 4:30 | The Code & Reproducibility
**Visual:** Show the `src/agent/test_generator.py` and `src/sandbox/runner.py`.
**Script:**
"I built this entirely in Python using the Gemini API. The most critical part is the sandbox runner, which isolates the execution so the agent can safely run untrusted code and capture the standard output and errors natively. I also implemented a structured JSON logging system so you can review the exact trajectory the agent took to solve the problem."

## 4:30 - 5:00 | Conclusion
**Visual:** Show the README or the final fixed code.
**Script:**
"VerifyAgent proves that we can escape the AI-washing trap. By forcing the AI to prove its code through execution, we bridge the Verification Gap and build actual trust in AI-generated software. The code is fully open-source and reproducible with just a Gemini API key. Thank you for watching!"
