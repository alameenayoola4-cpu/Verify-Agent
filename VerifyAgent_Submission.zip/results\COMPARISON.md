# VerifyAgent vs Baseline Comparison

## Summary Metrics

| Metric | Baseline (Static LLM) | VerifyAgent (Execution) |
|--------|----------------------|-------------------------|
| Total Bugs Found | 0 | **2** |
| Self-Healing Fixes | 0 | **1** |
| Final Pass Rate | Unknown | **12/12** |
| Avg Time per Case | 0.0s | 0.0s |

## Detailed Case Breakdown

| Case | Baseline Found | Agent Found | Agent Fixed | Tests Pass (After Fix) |
|------|----------------|-------------|-------------|------------------------|
| `case_01_array_utils` | 0 | **2** | ✅ | 12/12 |
| `case_02_rate_limiter` | 0 | **0** | ❌ | 0/0 |
| `case_03_password_validator` | 0 | **0** | ❌ | 0/0 |
| `case_04_csv_parser` | 0 | **0** | ❌ | 0/0 |
| `case_05_cache` | 0 | **0** | ❌ | 0/0 |
| `case_06_pagination` | 0 | **0** | ❌ | 0/0 |
| `case_07_retry` | 0 | **0** | ❌ | 0/0 |
| `case_08_date_utils` | 0 | **0** | ❌ | 0/0 |
| `case_09_permissions` | 0 | **0** | ❌ | 0/0 |
| `case_10_data_transformer` | 0 | **0** | ❌ | 0/0 |

## Conclusion

The static LLM baseline struggles to find subtle logical bugs and edge cases, often reporting 0 bugs or hallucinating non-issues.
VerifyAgent's execution-based approach reliably uncovers these issues and automatically fixes them.