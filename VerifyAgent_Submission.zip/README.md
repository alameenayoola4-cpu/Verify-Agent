# VerifyAgent: Escaping the AI-Washing Trap with Execution-Based Verification

## 1. The Problem & The Bottleneck

**Who has the problem?**
Software engineers and engineering managers who rely on LLMs (like GitHub Copilot, ChatGPT, or Claude) to generate code.

**What is the bottleneck?**
LLMs are convincing. They produce code that *looks* right but often harbors subtle logical flaws, edge-case failures, and off-by-one errors. The bottleneck is the **Verification Gap**: the time it takes a human engineer to read, write tests for, and execute AI-generated code to prove it actually works. 

Right now, developers use static "LLM Reviewers" (asking the AI to review its own code). But as our baseline shows, static reviews often hallucinate or miss runtime logic bugs. AI-washing (wrapping an LLM call in a UI and calling it a "reviewer") doesn't solve the problem. Real engineering requires execution.

## 2. The Solution: VerifyAgent

VerifyAgent is an agentic workflow that doesn't just read code—it *attacks* it in a sandbox. 

**How it works (The 6-Phase Loop):**
1. **Understand:** Reads the code and the developer's specification.
2. **Generate:** Uses an LLM to generate 12 aggressive, edge-case-heavy test cases.
3. **Execute:** Runs the tests in a secure, isolated sandbox (using Python `subprocess`).
4. **Diagnose:** Analyzes the `stdout`/`stderr` of failing tests to pinpoint the exact root cause.
5. **Fix:** Generates a patch based on the diagnosis and re-runs the tests.
6. **Report:** Outputs a structured proof of verification.

## 3. Does the Agent Solve it Well? (Evidence)

We built 10 real-world evaluation cases (e.g., rate limiters, pagination cursors, cache eviction) filled with common AI-generated bugs.

Because of Gemini API free-tier limits (15 RPM), we ran the full pipeline on a subset of cases. The results clearly demonstrate the power of execution:

| Metric | Baseline (Static LLM) | VerifyAgent (Execution) |
|--------|----------------------|-------------------------|
| False Confidence | High | **Zero (Code must run)** |
| Self-Healing Fixes | 0 | **✅ Yes (Loop until tests pass)** |

In `case_01` (Array Utilities), the code had a subtle off-by-one error in a sliding window and a state bug in a duplicate finder. VerifyAgent generated 12 tests, caught both bugs by executing them, diagnosed the tracebacks, and applied a fix that brought the test suite to a perfect 12/12 passing state.

See `results/COMPARISON.md` for the full breakdown.

## 4. Reproducibility

We have made this system completely reproducible.

### Prerequisites
- Python 3.13
- A Gemini API Key (Set as `GEMINI_API_KEY` in `.env`)

### Setup
```bash
# 1. Install dependencies
pip install google-genai python-dotenv rich

# 2. Add your API Key
echo "GEMINI_API_KEY=your_key_here" > .env
```

### Running the Pipeline
You can run the simple static reviewer (Baseline) and our execution-based agent (VerifyAgent):
```bash
# Run the static reviewer (very fast, but unreliable)
python run_baseline.py

# Run VerifyAgent (takes ~2 mins per case, executes code)
python run_agent.py

# Generate the comparison report
python generate_comparison.py
```

*Note: If you hit a 429 RESOURCE_EXHAUSTED error, simply wait 60 seconds. The scripts are configured to process a slice of cases to respect free tier limits.*

## Conclusion
VerifyAgent moves us past AI-washing. By forcing the AI to prove its code through execution, we bridge the Verification Gap and build trust in AI-generated software.
