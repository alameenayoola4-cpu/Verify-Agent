"""Gemini LLM client wrapper for VerifyAgent."""

import os
import json
import time
from pathlib import Path
from google import genai
from google.genai import types
from dotenv import load_dotenv

load_dotenv()


class GeminiClient:
    """Wrapper around the Gemini API for VerifyAgent operations."""

    def __init__(self, model: str = "gemini-3.6-flash"):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError(
                "GEMINI_API_KEY not set. Copy .env.example to .env and add your key."
            )
        self.client = genai.Client(api_key=api_key)
        self.model = model
        self.trajectory: list[dict] = []

    def generate(
        self,
        prompt: str,
        system_instruction: str | None = None,
        temperature: float = 0.2,
        response_mime_type: str | None = None,
    ) -> str:
        """Send a prompt to Gemini and return the text response."""
        start_time = time.time()

        config = types.GenerateContentConfig(
            temperature=temperature,
        )
        if system_instruction:
            config.system_instruction = system_instruction
        if response_mime_type:
            config.response_mime_type = response_mime_type

        max_retries = 5
        base_delay = 2.0
        
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model,
                    contents=prompt,
                    config=config,
                )
                break
            except Exception as e:
                if attempt == max_retries - 1:
                    raise
                if "503" in str(e) or "429" in str(e):
                    time.sleep(base_delay * (2 ** attempt))
                else:
                    raise

        elapsed = time.time() - start_time
        result_text = response.text or ""

        # Log trajectory
        self.trajectory.append({
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "model": self.model,
            "system_instruction": system_instruction[:200] + "..." if system_instruction and len(system_instruction) > 200 else system_instruction,
            "prompt_preview": prompt[:300] + "..." if len(prompt) > 300 else prompt,
            "prompt_length": len(prompt),
            "response_preview": result_text[:300] + "..." if len(result_text) > 300 else result_text,
            "response_length": len(result_text),
            "latency_seconds": round(elapsed, 2),
            "temperature": temperature,
        })

        return result_text

    def generate_json(
        self,
        prompt: str,
        system_instruction: str | None = None,
        temperature: float = 0.1,
    ) -> dict | list:
        """Send a prompt and parse the response as JSON."""
        result = self.generate(
            prompt=prompt,
            system_instruction=system_instruction,
            temperature=temperature,
            response_mime_type="application/json",
        )
        return json.loads(result)

    def save_trajectory(self, path: Path) -> None:
        """Save the full conversation trajectory to a JSON file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.trajectory, f, indent=2, ensure_ascii=False)

    def reset_trajectory(self) -> None:
        """Clear the trajectory log."""
        self.trajectory = []
