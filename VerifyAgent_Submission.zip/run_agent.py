"""
Run the VerifyAgent on all evaluation cases.

Usage:
    py run_agent.py                    # Run on all cases
    py run_agent.py case_01_array_utils  # Run on specific case
"""

import sys
import json
from pathlib import Path
from src.agent.orchestrator import VerifyAgentOrchestrator

CASES_DIR = Path("evaluation/cases")
RESULTS_DIR = Path("results/agent")


def load_case(case_dir: Path) -> dict:
    """Load a single evaluation case."""
    code = (case_dir / "code.py").read_text(encoding="utf-8")
    spec = (case_dir / "spec.md").read_text(encoding="utf-8")
    ground_truth = json.loads((case_dir / "ground_truth.json").read_text(encoding="utf-8"))
    return {
        "case_id": ground_truth["case_id"],
        "code": code,
        "spec": spec,
        "ground_truth": ground_truth,
    }


def run_all(filter_case: str | None = None):
    """Run VerifyAgent on all (or filtered) evaluation cases."""
    agent = VerifyAgentOrchestrator(max_fix_attempts=2)
    
    case_dirs = sorted(CASES_DIR.iterdir())
    if filter_case:
        case_dirs = [d for d in case_dirs if filter_case in d.name]
    
    cases = []
    for item in case_dirs:
        if item.is_dir():
            cases.append(load_case(item))
            
    # Run only 3 cases to respect Gemini free tier rate limits
    cases = cases[:3]
    
    all_reports = []
    
    for case in cases:
        print(f"\n{'#'*60}")
        print(f"  Running VerifyAgent on: {case['case_id']}")
        print(f"{'#'*60}")
        
        report = agent.verify(
            case_id=case["case_id"],
            code=case["code"],
            spec=case["spec"],
        )
        
        agent.save_report(report, RESULTS_DIR)
        all_reports.append(report.to_dict())
    
    # Save summary
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    summary_path = RESULTS_DIR / "summary.json"
    
    summary = {
        "total_cases": len(all_reports),
        "cases": [],
    }
    
    for r in all_reports:
        summary["cases"].append({
            "case_id": r["case_id"],
            "tests_passed": r["tests_passed"],
            "tests_failed": r["tests_failed"],
            "total_tests": r["total_tests"],
            "bugs_found": r["bug_count"],
            "fix_improved": r["fix_improved"],
            "post_fix_passed": r["post_fix_passed"],
            "time_seconds": r["total_time_seconds"],
        })
    
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  AGENT RUN COMPLETE")
    print(f"  Results saved to: {RESULTS_DIR}")
    print(f"  Cases processed: {len(all_reports)}")
    print(f"{'='*60}")


if __name__ == "__main__":
    filter_case = sys.argv[1] if len(sys.argv) > 1 else None
    run_all(filter_case)
